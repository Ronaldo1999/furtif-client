import Serveur from '../assets/serveur.json';

export const environment = {
  production: true,
  url: Serveur.serverIP,
};
