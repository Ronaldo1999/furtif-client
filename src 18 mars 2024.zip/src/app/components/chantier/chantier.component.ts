import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chantier',
  templateUrl: './chantier.component.html',
  styleUrls: ['./chantier.component.scss']
})
export class ChantierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
