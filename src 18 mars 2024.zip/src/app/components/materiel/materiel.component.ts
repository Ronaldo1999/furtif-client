import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-materiel',
  templateUrl: './materiel.component.html',
  styleUrls: ['./materiel.component.scss']
})
export class MaterielComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
