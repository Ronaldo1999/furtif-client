$("input[type='submit']").click(function () {
  $("div.spanner").addClass("show");
  $("div.overlay").addClass("show");
});
