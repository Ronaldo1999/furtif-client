import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categorie-client-dialog',
  templateUrl: './categorie-client-dialog.component.html',
  styleUrls: ['./categorie-client-dialog.component.scss']
})
export class CategorieClientDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
