import { Groupe } from './groupe';

describe('Groupe', () => {
  it('should create an instance', () => {
    expect(new Groupe()).toBeTruthy();
  });
});
