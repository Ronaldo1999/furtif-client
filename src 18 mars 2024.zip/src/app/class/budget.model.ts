export class Budget {
  id!: number;
  budgetID!: string;
  montant!: number;
  datedebutconso!: string;
  datefinconso!: string;
  seuilcritique!: number;
  montantinit!: number;
  montantactuel!: number;
  userid!: string;
  usereid!: number;
  parent!: number;
  creeLe!: string;
  creePar!: string;
  modifierLe!: string;
  modifierPar!: string;
  version!: number;
}