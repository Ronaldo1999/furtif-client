export class Arbre {
    arbreID!: string;
    arbreCorrespondantID!: string;
    arbreTypeID!: string;
    code!: string;
    libelleFr!: string;
    libelleUs!: string;
    ip_update!: string;
    last_update!: string;
    user_update!: string;
    organisationID!: string;
    dateValidation!: string;
    creation_date!: string;
    liens!: string;
    // fg
    // arbreDetailParentID!: string;
    // arbreNiveauID!: number;
    // posX!: number;
    // posY!: number;
    // extremiteLienID!: number;
}
