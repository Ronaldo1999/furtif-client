import { Dossier } from './dossier';

describe('Dossier', () => {
  it('should create an instance', () => {
    expect(new Dossier()).toBeTruthy();
  });
});
