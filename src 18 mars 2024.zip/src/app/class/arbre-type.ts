export class ArbreType {
    arbreTypeID!: string;
    code!: string;
    libelleFr!: string;
    libelleUs!: string;
    ip_update!: string;
    last_update!: string;
    user_update!: string;
}
