export class PartieProduit {
  etat!: number;
  idpartiesproduitspfnl!: any;
  idpartiesrecoltees!: any;
  idproduitspfnl!: any;
  idunitemesure!: any;
  idunitemesureexport!: any;
  libelleunitemesure!: string;
  nomcommercial!: any;
  nompartierecoltee!: any;
}

export class ElePartieProduit {
  idpartiesproduitspfnl!: number;
  idpartiesrecoltees!: number;
  idproduitspfnl!: number;
  idunitemesure!: number;
  idunitemesureexport!: number;
  libelleunitemesure!: string;
  nomcommercial!: string;
  nompartierecoltee!: string;
}
