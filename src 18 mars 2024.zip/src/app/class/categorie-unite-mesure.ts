export class CategorieUniteMesure {
    idcategorieunitemesure!: string;
    libellecategorie!: string;
}
