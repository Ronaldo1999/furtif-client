import { Localite } from './localite';

describe('Localite', () => {
  it('should create an instance', () => {
    expect(new Localite()).toBeTruthy();
  });
});
