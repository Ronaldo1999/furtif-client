export class Contrat {
  id!: number;
  contratID!: string;
  projetID!: string;
  clientID!: string;
  temoin1!: string;
  temoin2!: string;
  datesignature!: string;
  lieusignature!: string;
  close!: string;
  userid!: string;
  usereid!: number;
  parent!: number;
  creeLe!: string;
  creePar!: string;
  modifierLe!: string;
  modifierPar!: string;
  version!: number;
}
