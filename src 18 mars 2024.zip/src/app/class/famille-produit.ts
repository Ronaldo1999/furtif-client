export class FamilleProduit {
    idfamillepfnl!: string;
    nomfamille!: string;
  
}