export class Attribution {
  userdepartID!: number;
  userID!: string;
  localiteID!: number;
  commentaire!: string;
}
