import { Structure } from './structure';

describe('Structure', () => {
  it('should create an instance', () => {
    expect(new Structure()).toBeTruthy();
  });
});
