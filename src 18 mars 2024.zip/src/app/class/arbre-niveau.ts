export class ArbreNiveau {
    arbreNiveauID!: string;
    arbreTypeID!: string;
    couleur!: string;
    code!: number;
    libelleFr!: string;
    libelleUs!: string;
    ip_update!: string;
    last_update!: string;
    user_update!: string;
}
