export class Projet {
  projetID!: string;
  objet!: string;
  description!: string;
  typeprojet!: string;
  datedebut!: string;
  datefin!: string;
  dateline!: string;
  parentID!: string;
  created_at!: string;
  created_by!: string;
  last_update!: string;
  user_update!: string;
  ip_update!: string;
  clientID!: string;
  entreprise!: number;
}