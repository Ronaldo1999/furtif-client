export class Certificat{
  idceqe!:number;
  numeroceqe!:string;
  datedelivrance!:string;
  observation!:string;
  idpermissionnaire!:number;
  nomfichier!:string;
  cheminfichier!:string;
  idpermis!:number;
  /* Certificat origine */
  idcertificatorigine!:number;
  quantite!:number;
  idpartieproduitpfnl!:number;
  idunitemesure!:number;
  numeroco!:string;
  destinataire!:string;
  idpays!:number;
  type!:number;
}
