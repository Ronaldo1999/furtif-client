import { ResponseFile } from './response-file';

describe('ResponseFile', () => {
  it('should create an instance', () => {
    expect(new ResponseFile()).toBeTruthy();
  });
});
