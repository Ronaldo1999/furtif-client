export class Avenant {
  id!: number;
  avenantID!: string;
  projetID!: string;
  clientID!: string;
  temoin1!: string;
  temoin2!: string;
  raison!: string;
  datesignature!: string;
  lieusignature!: string;
  close!: string;
  userid!: string;
  usereid!: number;
  parent!: number;
  creeLe!: string;
  creePar!: string;
  modifierLe!: string;
  modifierPar!: string;
  version!: number;
}