descriptionsommaire : null
iddepartements : 0
iddetailpermis : 0
idpartieproduitpfnl : 11
idpermis : 8
idregions : 4
idunitemesure : 1
libelleunitemesure : "kilogramme"
nomcommercial : "Charbon de bois vert"
nompartierecoltee : "GRANULES"
nomregion : "EST"
nomscientifique : null
observation : null
quantite : 50