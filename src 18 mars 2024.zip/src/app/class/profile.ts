export class Profil {
  idprofil!: any;
  libelleFr!: any;
  libelleUs!: any;
  code!: any;
  created_at!: any;
  created_by!: any;
  last_update!: any;
  user_update!: any;
  ip_update!: any;
}
