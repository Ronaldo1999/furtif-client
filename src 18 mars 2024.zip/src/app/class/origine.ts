

export class OrigineProduit {
  idoriginespnfls!: number;
  nomsource!: string;
  originepnfl!: number;
}