export class Objectif {

  last_update !: Date
  user_update !: string
  ip_update !: string
  libelleFr !: string
  libelleUs !: string
  code !: string
  objectifID!: string
  niveauObjectfifID !: number
  objectfifParentID!: string
  organisationID!: string
  structureID!: string
  activitestrategiqueID!: string
  cadreLogiqueObjectifNiveauID!: number
  referenceDesignation!: string
  numOrdre!: number
  sigle!: string
  libelleParent!: string
  libelleGrandParent!: string
  nbFils!: number
  nbPetitFils!: number
  color!: string
  
}


