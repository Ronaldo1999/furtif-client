export class Permissionnaire {
  adressep:any;
  codePNFL:any;
  contact:any;
  iDPermissionnairesPNFL:any;
  idcommune:any;
  libelleunitemesure:any;
  mail:any;
  nUI:any;
  nUMCEQE:any;
  natureactivite:any;
  nbreemploye:any;
  nomouraisonsociale:any;
  nomregion:any;
  numeropermis:any;
  profession:any;
  qualite:any;
  qualiteexploitant:any;
  quantite:any;
  sexe:any;
  siegesocial:any;
  statut:any;
  typepersonne:any;
}

    






