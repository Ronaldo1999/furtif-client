export class UniteMesure {
  idunitemesure!: any;
  libelleunitemesure!: any;
  idcategorie!: any;
  arrondi!: any;
  ordregrandeur!: any;
  ratio!: any;
  actif!: boolean;

  idcategorieunitemesure!: string;
  libellecategorie!: string;
}
