export class Demande {
  adresse!: any;
  contact!: any;
  dateexpiration!: any;
  description!: any;
  email!: any;
  espece!: any;
  etat!: any;
  idpartiesrecoltees!: any;
  idproduit!: any;
  idproduitdemande!: any;
  idunitemesure!: any;
  idvendeur!: any;
  last_update!: any;
  libelleunitemesure!: any;
  nomdemandeur!: any;
  nompartierecoltee!: any;
  quantite!: any;
  ville!: any;
}
