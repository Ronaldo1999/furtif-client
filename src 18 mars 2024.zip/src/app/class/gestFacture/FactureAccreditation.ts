






export class FactureAccreditation {
    
    ip_update!: string;
    last_update!: string;
    user_update!: string;
    fonction!: string;
    nom!: string;
    matriculeOrdo!: string;
    actif!: number;

}
