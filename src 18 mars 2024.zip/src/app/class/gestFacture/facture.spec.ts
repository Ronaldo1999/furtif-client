import { Facture } from './facture';

describe('Facture', () => {
  it('should create an instance', () => {
    expect(new Facture()).toBeTruthy();
  });
});
