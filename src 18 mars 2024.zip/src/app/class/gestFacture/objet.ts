export class Objet {
    x:string=''
    y:number=0
}
