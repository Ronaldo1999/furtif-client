export class MissionAgent {
    matricule!: string;
    nom!: string;
    prenom!: string;
    nbOM!: number;
    nbJours!: number;
}
