export class FactureFournisseur {
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    fournisseurID!: string;
    numContribuable!: string;
    raisonSociale!: string;
    adresse!: string;
    rib!: string;
    banque!: string;
    agence!: string;
    fourBudgetaire!: number;
    registrecm!: string;
    telephone!: string;
   
}