export class CategorieProduit {
  idcategorieproduit!: number;
  libellecategorie!: string;
  codecategorie!: any;
  observation!: any;
  quotas!: boolean;
  etat!: number;
}
