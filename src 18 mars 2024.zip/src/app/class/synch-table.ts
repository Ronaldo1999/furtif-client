export class SynchTable {
  id!: number;
  libelle!: string;
  val!: string;
}