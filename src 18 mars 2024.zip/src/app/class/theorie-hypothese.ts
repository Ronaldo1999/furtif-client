export class TheorieHypothese {
    theorieHypotheseID!: string;
    code!: string;
    libelleFr!: string;
    libelleUs!: string;
    typeHypothese!: string;
    last_update!: string;
    ip_update!: string;
    user_update!: string;
    organisationID!: string;
    theoriechangementID!: string;
    creation_date!: string;
}
