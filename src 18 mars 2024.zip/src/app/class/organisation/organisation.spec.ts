import { Organisation } from './organisation';

describe('Organisation', () => {
  it('should create an instance', () => {
    expect(new Organisation()).toBeTruthy();
  });
});
