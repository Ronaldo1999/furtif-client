export class TypeDocument {
  idtypedocument!: number;
  libelletypedocument!: string;
  code!: string;
}
