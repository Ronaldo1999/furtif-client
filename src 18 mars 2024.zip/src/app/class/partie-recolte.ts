export class PartieRecolte {
    idpartiesrecoltees!: any;
    nompartierecoltee!: any;
   
}
