export class BcaArticle{
    amId!:string;
    millesime!:string;
    numRubrique!:string;
    numSousRubrique!:string;
    refArticle!:string;
    dateDebutValid!:string;
    dateFinValid!:string;
    designation!:string;
    conditionnement!:string;
    prixDeReference!:number;
    prixMax!: number;
    srId!:string;
    homologation!:string;
    user_update!:string;
    last_update!:string;
}