import { Ranking } from './ranking';

describe('Ranking', () => {
  it('should create an instance', () => {
    expect(new Ranking()).toBeTruthy();
  });
});
