export class BalancedScoreCard {

    bscID!: string; dcrID!: number;
    organisationID!: string; structureID!: string; activiteID!: string;
    millesime!: string; titre!: string; version!: number;
    mois!: string; dateGenere!: string; user_update!: string; last_update!: string;
    valide!: string; userValide!: string; dateValidation!: string;
    note!: string; poids!: number; taux!: number;
}
