export class DomaineCleResultat {

    dcrID!: number;
    libelleFr!: string;
    libelleUs!: string;
    user_update!: string;
    last_update!: string;
    organisationID!: string;
    millesime!: string;
}
