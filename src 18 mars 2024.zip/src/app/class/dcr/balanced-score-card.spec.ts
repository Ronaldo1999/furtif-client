import { BalancedScoreCard } from './balanced-score-card';

describe('BalancedScoreCard', () => {
  it('should create an instance', () => {
    expect(new BalancedScoreCard()).toBeTruthy();
  });
});
