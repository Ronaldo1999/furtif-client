import { DomaineCleResultat } from './domaine-cle-resultat';

describe('DomaineCleResultat', () => {
  it('should create an instance', () => {
    expect(new DomaineCleResultat()).toBeTruthy();
  });
});
