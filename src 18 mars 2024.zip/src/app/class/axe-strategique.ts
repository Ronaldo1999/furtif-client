export class AxeStrategique {
    axestrategiqueID !: string;
    last_update !: string;
    user_update !: string;
    ip_update !: string;
    libelleFr !: string;
    libelleUs !: string;
    numordre !: number;
    organisationID !: string;
    creation_date !: string;
    arbre_objectifs !: string;
    structureID !: string;
    color!: string;
    visibilte!: string;

}