
export class ObjectifTheorie {
    objectiftheorieID !: string
    last_update !: string
    user_update !: Date
    ip_update !: string
    code !: string
    libelleFr !: string
    libelleUs !: string
    objectiftheorieNiveauID !: number
    objectiftheorieParentID !: string
    theoriechangementID !: string
    organisationID !: string
    structureID !: string
    referenceDesignation !: string
    sigle !: string
    numOrdre !: number
    activitetheorieID !: string
    creation_date !: string

}
