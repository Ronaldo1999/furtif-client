export class Vendeur {
  adresse!: any;
  categorieCollecteur!: any;
  contact!: any;
  dateNaissance!: any;
  datedelivrance!: any;
  datefin!: any;
  email!: any;
  idprofil!: any;
  idprofilvendeur!: any;
  idvendeur!: any;
  last_update!: any;
  libelleprofil!: any;
  listesassocies!: any;
  nom!: any;
  numeropermis!: any;
  password!: any;
  typecouverture!: any;
  user_update!: any;
  role_as!: any;
  validation!: any;
  ville!: any;
  action!: any;
  parentID!: any;

  adressep!: any;
  codePNFL!: any;
  iDPermissionnairesPNFL!: any;
  idcommune!: any;
  idlocalite!: any;
  idregion!: any;
  iddepartement!: any;
  libelleunitemesure!: any;
  mail!: any;
  nUI!: any;
  nUMCEQE!: any;
  natureactivite!: any;
  nbreemploye!: any;
  nomouraisonsociale!: any;
  nomregion!: any;
  profession!: any;
  qualite!: any;
  qualiteexploitant!: any;
  quantite!: any;
  sexe!: any;
  siegesocial!: any;
  statut!: number;
  typepersonne!: any;
  etat!: number;

  idtypedocument!: any;

  code!:any;
  codeOrder!:any;
  codeParent!:any;
  contactacteur!:any;
 
  emailacteur!:any;
  nomacteur!:any;

}
