export class Sensibilite {
    idCourrierSensibilite!:string
    code:string=''
    libelleFr:string=''
    libelleUs:string=''
    userupdate!:string;
    ipupdate!:string;
}
