import { Sensibilite } from './sensibilite';

describe('Sensibilite', () => {
  it('should create an instance', () => {
    expect(new Sensibilite()).toBeTruthy();
  });
});
