import { UserGlobal } from './user-global';

describe('UserGlobal', () => {
  it('should create an instance', () => {
    expect(new UserGlobal()).toBeTruthy();
  });
});
