export class Dossier {

    idClasseur!: string
    code!: string
    libelleFr!: string
    libelleUs!: string
    description!: string
    localisationphysique!: string
    image: any
    loginInitiator!: string
    idClasseurParent!: string
    userupdate!: string;
    ipupdate!: string;
    organisationID!: string;
    structureID!: string;
    prive!: number;
    archive!: number;

}
