export class UserActeur {
  pfnluseracteurID!: any;
  userID!: any;
  acteurID!: any;
  created_date!: any;
  user_update!: any;
  last_update!: any;
  ip_update!: any;
  typeuser!: number;
  localiteID!: number;
  
}
