import { Typeuser } from './typeuser';

describe('Typeuser', () => {
  it('should create an instance', () => {
    expect(new Typeuser()).toBeTruthy();
  });
});
