export class Typeuser {
    typeuserID!:string;
    libelleFr!:string;
    libelleUs!:string;
    role!:string;
    userupdate!:string;
    ipupdate!:string;
}
