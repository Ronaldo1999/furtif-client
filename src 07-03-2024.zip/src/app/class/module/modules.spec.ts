import { Modules } from './modules';

describe('Modules', () => {
  it('should create an instance', () => {
    expect(new Modules()).toBeTruthy();
  });
});
