export class Message {

    messagerieID:string = ""
    loginE:string = ""
    moduleID: string = ""
    statut: boolean= false
    objet!:string 
    titre:string = ""
    type:string = ""
    date:any

}
