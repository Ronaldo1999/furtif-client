export class GlobalLocalite {
  idpfnlgloballocalite!: any;
  idcommunes!: any;
  nomcommune!: any;
  codecommune!: any;
  idlocalite!: any;
  idcommune!: any;
  idpostecontrole!: any;
  nomlocalite!: any;
  iddepartements!: any;
  codedepartement!: any;
  nomdepartement!: any;
  nomcheflieu!: any;
  idregions!: any;
  idpays!: any;
  nompays!: any;
  codepays!: any;
  nomregion!: any;
  coderegion!: any;
  descriptionregions!: any;
  cheflieuregion!: any;
  abreviationregion!: any;
  niveau!: any;
  codeposte!: any;
  intituleposte!: any;
  posteexport!: any;
  nom!: any;
}

export class LocaliteDepart {
  commentaire!: any;
  localiteID!: any;
  nomlocalite!: any;
  userID!: any;
  userdepartID!: any;
}
